const express = require("express");
var router = express.Router();
var { Employee } = require("../models/empexcel");
var ObjectId = require("mongoose").Types.ObjectId;
const multer = require("multer");
var XLSX = require("xlsx");
var storage = multer.diskStorage({
  destination: function(req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function(req, file, cb) {
    cb(null, "-" + Date.now() + file.originalname);
  }
});

var upload = multer({ storage: storage });

router.post("/upload", upload.single("productImage"), (req, res) => {
  console.log("%%%%%%%%%%%%%%%%%%%%");
  console.log(req.file);
  var workbook = XLSX.readFile(req.file.path);
  var sheet_name_list = workbook.SheetNames;
  var xlData1 = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[0]]);

  var xlData2 = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list[1]]);

  console.log(xlData1);
  console.log(xlData2);

  res.send({
    data1: xlData1,
    data2: xlData2
  });

  //   var path = req.file.path;
  //   if (req.file.path == "undefined") {
  //     path = "uploads/-15604102410694.jpeg";
  //   }
  //   mobno = req.body.mobno !== "undefined" ? req.body.mobno : "";
  //   req.body.state = req.body.state !== "undefined" ? req.body.state : "";
  //   req.body.address = req.body.address !== "undefined" ? req.body.address : "";

  //   req.body.city = req.body.city !== "undefined" ? req.body.city : "";
  //   req.body.zip = req.body.zip !== "undefined" ? req.body.zip : "";
  //   req.body.techskill =
  //     req.body.techskill !== "undefined" ? req.body.techskill : "";
  //   req.body.salary = req.body.salary !== "undefined" ? req.body.salary : "";
  //   req.body.hobbiesPreferences =
  //     req.body.hobbiesPreferences !== "undefined"
  //       ? req.body.hobbiesPreferences
  //       : "";
  //   req.body.dob = req.body.dob !== "undefined" ? req.body.dob : "";
  //   req.body.gender = req.body.gender !== "undefined" ? req.body.gender : "";
  //   var user = new Employee({
  //     // name: req.body.name
  //     fname: req.body.fname,
  //     lname: req.body.lname,
  //     email: req.body.email,
  //     mobno: mobno,
  //     dob: req.body.dob,
  //     address: req.body.address,
  //     zip: req.body.zip,
  //     state: req.body.state,
  //     city: req.body.city,
  //     gender: req.body.gender,
  //     techskill: req.body.techskill,
  //     salary: req.body.salary,
  //     hobbiesPreferences: req.body.hobbiesPreferences,
  //     productImage: path
  //   });
  // console.log(user);
  // user.save((err, doc) => {
  //   if (!err) {
  //     res.send(doc);
  //   } else {
  //     console.log(err);
  //   }
  // });
});

module.exports = router;
