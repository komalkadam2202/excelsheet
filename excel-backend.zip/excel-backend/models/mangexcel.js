const mongoose = require("mongoose");

var user = mongoose.model("employee_excel", {
  _id: mongoose.Schema.Types.ObjectId,
  fname: { type: String },
  lname: { type: String },
  email: { type: String },
  status: { type: String },
  emp_code: { type: String }
});

module.exports = { user };
